﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Linq.Expressions;
using Menu_SGBr;
using Menu_SGBr.Properties;
using Microsoft.EntityFrameworkCore;
using static Menu_SGBr.Classes.DataContext;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;
using Menu_SGBr.Classes;
using FirebirdSql.Data.FirebirdClient;
using Menu_SGBr.Class;
using NLog;


namespace Menu_SGBr
{
    public partial class Menu : Form
    {
        private static readonly Logger Logger = LogManager.GetCurrentClassLogger();

        public Menu()
        {
            this.Width = Screen.PrimaryScreen.Bounds.Width;

            this.Height = 200;

            this.StartPosition = FormStartPosition.Manual;
            this.Location = new System.Drawing.Point(0, 0);

            Clientes FormCliente = new Clientes();
            estoque FormEst = new estoque();
            Fornecedores FormForn = new Fornecedores();

            this.StartPosition = FormStartPosition.Manual;
            this.Location = new System.Drawing.Point(0, 0);

            InitializeComponent();
        }


        [DllImport("DwmApi")]
        private static extern int DwmSetWindowAttribute(IntPtr hwn, int attr, int[] attrValue, int attriSize);

        protected override void OnHandleCreated(EventArgs e)
        {
            if (DwmSetWindowAttribute(Handle, 19, new[] { 1 }, 4) != 0)
            {
                DwmSetWindowAttribute(Handle, 20, new[] { 1 }, 4);
            }
        }


        private void BtnCli_Click(object sender, EventArgs e)
        {
            Clientes();
        }

        private void BtnForn_Click(object sender, EventArgs e)
        {
            Fornecedor();
        }

        private void BtnEst_Click_1(object sender, EventArgs e)
        {
           Estoque();
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        public async Task CarregarMenu()
        {

            var task1 = Task.Run(() => Clientes());
            var task2 = Task.Run(() => Estoque());
            var task3 = Task.Run(() => Fornecedor());

            await Task.WhenAll(task1, task2, task3);
            AtualizarMenu();

        }
        private void AtualizarMenu()
        {
            
        }
        private void Clientes()
        {
            using (Clientes clientes = new Clientes())
            {
                clientes.ShowDialog();
            }

        }
        private void Estoque()
        {
            using (estoque Estoques = new estoque())
            {
                Estoques.ShowDialog();
            }
        }
        private void Fornecedor()
        {
            using (Fornecedores Forn = new Fornecedores())
            {
                Forn.ShowDialog();
            }
        }

        private void SomeMethod()
        {
            try
            {
                Logger.Info("Método SomeMethod executado com sucesso.");
            }
            catch (Exception ex)
            {
                Logger.Error(ex, "Erro ao executar SomeMethod.");
            }
        }
       
    }
}
