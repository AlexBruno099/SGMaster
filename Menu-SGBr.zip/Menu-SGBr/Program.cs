﻿using Microsoft.Extensions.Logging;
using NLog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Menu_SGBr
{
    static class Program
    {
        private static readonly Logger Logger = LogManager.GetCurrentClassLogger();

        /// <summary>
        /// Ponto de entrada principal para o aplicativo.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // Log de inicialização da aplicação
            Logger.Info("Aplicação iniciada.");

            try
            {
                Application.Run(new Menu());
            }
            catch (Exception ex)
            {
                // Log de qualquer exceção não tratada
                Logger.Error(ex, "Erro não tratado.");
                throw;
            }
            finally
            {
                // Log de encerramento da aplicação
                Logger.Info("Aplicação encerrada.");
                LogManager.Shutdown();
            }
        }
    }
}
