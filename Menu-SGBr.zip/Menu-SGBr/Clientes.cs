﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FirebirdSql.Data.FirebirdClient;
using Menu_SGBr.Classes;
using Microsoft.EntityFrameworkCore;
using static Menu_SGBr.Classes.DataContext;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion.Internal;
using Menu_SGBr.Class;
using ExcelDataReader;
using System.IO;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;
using System.Data.SqlClient;
using System.Security.Cryptography.X509Certificates;
using OfficeOpenXml;
using System.Runtime.Remoting.Contexts;
using System.Linq;
using OfficeOpenXml.Style;
using NPOI.SS.UserModel;
using ClosedXML;
using ClosedXML.Excel;

namespace Menu_SGBr
{
    public partial class Clientes : Form
    {
        
        public Clientes()
        {
            this.Width = Screen.PrimaryScreen.Bounds.Width;

            this.Height = 200;
            
            InitializeComponent();

            ContextMenuStrip contextMenuStrip = new ContextMenuStrip();
            ToolStripMenuItem Importar = new ToolStripMenuItem("Importar Fornecedores .xls");
            ToolStripMenuItem Exportar = new ToolStripMenuItem("Exportar Fornecedores .xls");

            contextMenuStrip.Items.AddRange(new ToolStripItem[] { Importar, Exportar });

            Importar.Click += Importar_Click;
            Exportar.Click += Exportar_Click;

            this.ContextMenuStrip = contextMenuStrip;

            this.MouseDown += dataGridView1_MouseDown;
            LoadDataAsync();
        }

        [DllImport("DwmApi")]
        private static extern int DwmSetWindowAttribute(IntPtr hwn, int attr, int[] attrValue, int attriSize);

        protected override void OnHandleCreated(EventArgs e)
        {
            if (DwmSetWindowAttribute(Handle, 19, new[] { 1 }, 4) != 0)
            {
                DwmSetWindowAttribute(Handle, 20, new[] { 1 }, 4);
            }
        }
        public async Task LoadDataAsync()
        {
            using (var SGcontext = new DataContext.SgContext())
            {
                var clientes = await SGcontext.cliente.Take(100).ToListAsync();

                DataTable dataTable = new DataTable();
              
                dataTable.Columns.Add("Código", typeof(string));
                dataTable.Columns.Add("Cliente", typeof(string));
                dataTable.Columns.Add("Fantasia", typeof(string));
                dataTable.Columns.Add("CPF", typeof(string));
                dataTable.Columns.Add("CNPJ", typeof(string));
                dataTable.Columns.Add("Telefone", typeof(string));
                dataTable.Columns.Add("Celular", typeof(string));
                dataTable.Columns.Add("País", typeof(string));
                dataTable.Columns.Add("UF", typeof(string));
                dataTable.Columns.Add("Cidade", typeof(string));
                dataTable.Columns.Add("Bairro", typeof(string));
                dataTable.Columns.Add("Endereço", typeof(string));
                dataTable.Columns.Add("Número", typeof(string));
                dataTable.Columns.Add("CEP", typeof(string));
                dataTable.Columns.Add("Complemento", typeof(string));
                dataTable.Columns.Add("E-mail", typeof(string));
                dataTable.Columns.Add("E-mail2", typeof(string));
                dataTable.Columns.Add("Nacionalidade", typeof(string));
                dataTable.Columns.Add("Naturalidade", typeof(string));
                dataTable.Columns.Add("Data nascimento", typeof(DateTime));
                dataTable.Columns.Add("Tipo de cliente", typeof(string));
                dataTable.Columns.Add("RG", typeof(string));
                dataTable.Columns.Add("IE", typeof(string));
                dataTable.Columns.Add("Estado civil", typeof(string));
                dataTable.Columns.Add("Sexo", typeof(string));
                dataTable.Columns.Add("IM", typeof(string));
                dataTable.Columns.Add("Data e hora cadastro", typeof(DateTime));
                dataTable.Columns.Add("Pai", typeof(string));
                dataTable.Columns.Add("Mãe", typeof(string));
                dataTable.Columns.Add("Nome cônjuge", typeof(string));
                dataTable.Columns.Add("Nome contato jurídico", typeof(string));
                dataTable.Columns.Add("Data última venda", typeof(DateTime));
                dataTable.Columns.Add("Limite de crédito", typeof(decimal));
                dataTable.Columns.Add("Cód. convênio", typeof(string));
                dataTable.Columns.Add("Convênio", typeof(string));
                dataTable.Columns.Add("Profissão", typeof(string));
                dataTable.Columns.Add("Empresa", typeof(string));
                dataTable.Columns.Add("Fone trabalho", typeof(string));
                dataTable.Columns.Add("Renda mensal", typeof(decimal));
                dataTable.Columns.Add("Dias sem comprar", typeof(int));
                dataTable.Columns.Add("Código cidade IBGE", typeof(string));
                dataTable.Columns.Add("Status", typeof(string));
                dataTable.Columns.Add("Cód. vendedor", typeof(string));
                dataTable.Columns.Add("Vendedor", typeof(string));
                dataTable.Columns.Add("Ativo", typeof(string));
                dataTable.Columns.Add("Campo 1", typeof(string));
                dataTable.Columns.Add("Campo 2", typeof(string));
                dataTable.Columns.Add("Campo 3", typeof(string));
                dataTable.Columns.Add("Campo 4", typeof(string));
                dataTable.Columns.Add("Campo 5", typeof(string));
                dataTable.Columns.Add("Campo 6", typeof(string));
                dataTable.Columns.Add("Campo 7", typeof(string));
                dataTable.Columns.Add("Campo 8", typeof(string));
                dataTable.Columns.Add("Campo 9", typeof(string));
                dataTable.Columns.Add("Campo 10", typeof(string));

                foreach (var cliente in clientes)
                {
                    dataTable.Rows.Add(
                        cliente.Controle,
                        cliente.NomeCliente,
                        cliente.Fantasia,
                        cliente.CPF,
                        cliente.CNPJ,
                        cliente.Telefone,
                        cliente.Celular,
                        cliente.Pais,
                        cliente.UF,
                        cliente.Cidade,
                        cliente.Bairro,
                        cliente.Endereco,
                        cliente.Numero,
                        cliente.CEP,
                        cliente.Complemento,
                        cliente.Email,
                        cliente.Email2,
                        cliente.Nacionalidade,
                        cliente.Naturalidade,
                        cliente.DataNascimento,
                        cliente.TipoCliente,
                        cliente.RG,
                        cliente.IE,
                        cliente.EstadoCivil,
                        cliente.Sexo,
                        cliente.IM,
                        cliente.DataHoraCadastro,
                        cliente.Pai,
                        cliente.Mae,
                        cliente.NomeConjuge,
                        cliente.NomeContatoJuridica,
                        cliente.DataUltimaVenda,
                        cliente.LimiteCredito,
                        cliente.CodConvenio,
                        cliente.Convenio,
                        cliente.Profissao,
                        cliente.EmpresaQueTrabalha,
                        cliente.Telefone,
                        cliente.RendaMensal,
                        cliente.DiasSemComprar,
                        cliente.CodigoCidadeIBGE,
                        cliente.Status,
                        cliente.CodVendedor,
                        cliente.Vendedor,
                        cliente.Ativo,
                        cliente.Campo1,
                        cliente.Campo2,
                        cliente.Campo3,
                        cliente.Campo4,
                        cliente.Campo5,
                        cliente.Campo6,
                        cliente.Campo7,
                        cliente.Campo8,
                        cliente.Campo9,
                        cliente.Campo10
                        );
                }

                if (dataGridView1.InvokeRequired)
                {
                    dataGridView1.Invoke(new Action(() => dataGridView1.DataSource = dataTable));
                }
                else
                {
                    dataGridView1.DataSource = dataTable;
                }
            }
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
      
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private static List<Cliente> ReadXls(string filePath)
        {
            var response = new List<Cliente>();
            FileInfo existingFile = new FileInfo(filePath);
            if (!existingFile.Exists)
            {
                throw new FileNotFoundException("O arquivo Excel especificado não foi encontrado.", existingFile.FullName);
            }

            System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);

            try
            {
                using (var stream = File.Open(filePath, FileMode.Open, FileAccess.Read))
                {
                    using (var reader = ExcelReaderFactory.CreateReader(stream))
                    {
                        var result = reader.AsDataSet(new ExcelDataSetConfiguration()
                        {
                            ConfigureDataTable = (_) => new ExcelDataTableConfiguration()
                            {
                                UseHeaderRow = true
                            }
                        });

                        DataTable table = result.Tables[0];

                        var requiredColumns = new[] { "Cliente/Fornecedor", "Fantasia", "CPF", "RG/IE", "Endereço", "Complemento", "Bairro", "CEP", "Número", "UF", "Telefone/Celular", "E-mail" };
                        var missingColumns = requiredColumns.Where(column => !table.Columns.Contains(column)).ToList();

                        if (missingColumns.Any())
                        {
                            string missingColumnsMessage = string.Join(", ", missingColumns);
                            throw new Exception($"Coluna(s) obrigatória(s) não encontrada(s): {missingColumnsMessage}.");
                        }

                        foreach (DataRow row in table.Rows)
                        {
                            var cliente = new Cliente
                            {
                                NomeCliente = row["Cliente/Fornecedor"].ToString(),
                                Fantasia = row["Fantasia"].ToString(),
                                CPF = row["CPF"].ToString(),
                                IE = row["RG/IE"].ToString(),
                                Endereco = row["Endereço"].ToString(),
                                Complemento = row["Complemento"].ToString(),
                                Bairro = row["Bairro"].ToString(),
                                CEP = row["CEP"].ToString(),
                                Numero = row["Número"].ToString(),
                                UF = row["UF"].ToString(),
                                Telefone = row["Telefone/Celular"].ToString(),
                                Email = row["E-mail"].ToString()
                            };
                            response.Add(cliente);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Erro ao ler o arquivo Excel: {ex.Message}", ex);
            }

            return response;
        }

        private async void importarXlsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Filter = "Excel Files|*.xls;*.xlsx",
                Title = "Selecione um arquivo Excel"
            };
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string filePath = openFileDialog.FileName;
                try
                {
                    var messageBox = new Form { Text = "Progresso de Importação", Size = new Size(300, 100), StartPosition = FormStartPosition.CenterScreen };
                    var label = new Label { Text = "Iniciando a leitura do arquivo Excel...", Dock = DockStyle.Top };
                    var progressBar = new ProgressBar { Style = ProgressBarStyle.Continuous, Dock = DockStyle.Bottom };
                    messageBox.Controls.Add(progressBar);
                    messageBox.Controls.Add(label);
                    messageBox.Show();

                    List<Cliente> clientes = ReadXls(filePath);
                    progressBar.Maximum = clientes.Count;

                    if (clientes.Count > 0)
                    {
                        using (var context = new SgContext())
                        {
                            foreach (var cliente in clientes)
                            {
                                if (cliente.DataHoraCadastro == null)
                                {
                                    cliente.DataHoraCadastro = DateTime.Now;
                                }

                                var existingCliente = await context.cliente
                                    .AsNoTracking()
                                    .FirstOrDefaultAsync(f => f.CPF == cliente.CPF);

                                if (existingCliente == null)
                                {
                                    cliente.Ativo = "S";
                                    cliente.Controle = context.cliente.Max(f => (int?)f.Controle) + 1 ?? 1;
                                    context.cliente.Add(cliente);
                                }
                                else
                                {
                                    context.Entry(existingCliente).CurrentValues.SetValues(cliente);
                                }

                                await context.SaveChangesAsync();
                                progressBar.Value++;
                                label.Text = $"Importando cliente {progressBar.Value} de {progressBar.Maximum}...";
                            }
                        }

                        messageBox.Close();
                        MessageBox.Show("Clientes importados e salvos no banco de dados com sucesso.", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        using (var context = new SgContext())
                        {
                            dataGridView1.DataSource = context.cliente.ToList();
                        }
                    }
                    else
                    {
                        messageBox.Close();
                        MessageBox.Show("Nenhum cliente encontrado no arquivo.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
                catch (DbUpdateException ex)
                {
                    var innerException = ex.InnerException;
                    while (innerException?.InnerException != null)
                    {
                        innerException = innerException.InnerException;
                    }
                    MessageBox.Show($"Erro ao importar o arquivo: {innerException?.Message ?? ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Erro ao importar o arquivo: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }



        private async void pictureBox1_Click(object sender, EventArgs e)
        {
            if (BuscaBox.Checked)
            {
                try
                {
                    using (var SGcontex = new DataContext.SgContext())
                    {
                        await SGcontex.Database.OpenConnectionAsync();

                        string selectSql = "SELECT * FROM TCLIENTE";

                        using (FbDataAdapter dataAdapter = new FbDataAdapter(selectSql, (FbConnection)SGcontex.Database.GetDbConnection()))
                        {
                            DataTable dataTable = new DataTable();

                            await Task.Run(() => dataAdapter.Fill(dataTable));

                            if (dataGridView1.InvokeRequired)
                            {
                                dataGridView1.Invoke(new Action(() => dataGridView1.DataSource = dataTable));
                            }
                            else
                            {
                                dataGridView1.DataSource = dataTable;
                            }
                        }
                    }
                }
                catch (Exception ex)
                {

                }
            }
            else
            {

            }
        }
        private async void Importar_Click(object sender, EventArgs e)
        {

            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Filter = "Excel Files|*.xls;*.xlsx",
                Title = "Selecione um arquivo Excel"
            };
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string filePath = openFileDialog.FileName;
                try
                {
                    var messageBox = new Form { Text = "Progresso de Importação", Size = new Size(300, 100), StartPosition = FormStartPosition.CenterScreen };
                    var label = new Label { Text = "Iniciando a leitura do arquivo Excel...", Dock = DockStyle.Top };
                    var progressBar = new ProgressBar { Style = ProgressBarStyle.Continuous, Dock = DockStyle.Bottom };
                    messageBox.Controls.Add(progressBar);
                    messageBox.Controls.Add(label);
                    messageBox.Show();

                    List<Cliente> clientes = ReadXls(filePath);
                    progressBar.Maximum = clientes.Count;

                    if (clientes.Count > 0)
                    {
                        using (var context = new SgContext())
                        {
                            foreach (var cliente in clientes)
                            {
                                if (cliente.DataHoraCadastro == null)
                                {
                                    cliente.DataHoraCadastro = DateTime.Now;
                                }

                                var existingCliente = await context.cliente
                                    .AsNoTracking()
                                    .FirstOrDefaultAsync(f => f.CPF == cliente.CPF);

                                if (existingCliente == null)
                                {
                                    cliente.Ativo = "S";
                                    cliente.Controle = context.cliente.Max(f => (int?)f.Controle) + 1 ?? 1;
                                    context.cliente.Add(cliente);
                                }
                                else
                                {
                                    context.Entry(existingCliente).CurrentValues.SetValues(cliente);
                                }

                                await context.SaveChangesAsync();
                                progressBar.Value++;
                                label.Text = $"Importando cliente {progressBar.Value} de {progressBar.Maximum}...";
                            }
                        }

                        messageBox.Close();
                        MessageBox.Show("Clientes importados e salvos no banco de dados com sucesso.", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        using (var context = new SgContext())
                        {
                            dataGridView1.DataSource = context.cliente.ToList();
                        }
                    }
                    else
                    {
                        messageBox.Close();
                        MessageBox.Show("Nenhum cliente encontrado no arquivo.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
                catch (DbUpdateException ex)
                {
                    var innerException = ex.InnerException;
                    while (innerException?.InnerException != null)
                    {
                        innerException = innerException.InnerException;
                    }
                    MessageBox.Show($"Erro ao importar o arquivo: {innerException?.Message ?? ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Erro ao importar o arquivo: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        private async void Exportar_Click(object sender, EventArgs e)
        {
            using (SaveFileDialog sfd = new SaveFileDialog() { Filter = "Excel Workbook|*.xlsx" })
            {
                if (sfd.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        var messageBox = new Form { Text = "Progresso de Exportação", Size = new Size(300, 100), StartPosition = FormStartPosition.CenterScreen };
                        var label = new Label { Text = "Iniciando a exportação para Excel...", Dock = DockStyle.Top };
                        var progressBar = new ProgressBar { Style = ProgressBarStyle.Continuous, Dock = DockStyle.Bottom };
                        messageBox.Controls.Add(progressBar);
                        messageBox.Controls.Add(label);
                        messageBox.Show();

                        await Task.Run(() =>
                        {
                            using (var workbook = new XLWorkbook())
                            {
                                var worksheet = workbook.Worksheets.Add("Sheet1");

                                progressBar.Invoke((MethodInvoker)delegate { progressBar.Maximum = dataGridView1.Rows.Count; });

                                for (int i = 0; i < dataGridView1.Columns.Count; i++)
                                {
                                    worksheet.Cell(1, i + 1).Value = dataGridView1.Columns[i].HeaderText;
                                }

                                for (int i = 0; i < dataGridView1.Rows.Count; i++)
                                {
                                    for (int j = 0; j < dataGridView1.Columns.Count; j++)
                                    {
                                        worksheet.Cell(i + 2, j + 1).Value = dataGridView1.Rows[i].Cells[j].Value?.ToString();
                                    }

                                    progressBar.Invoke((MethodInvoker)delegate { progressBar.Value = i + 1; });
                                    label.Invoke((MethodInvoker)delegate { label.Text = $"Exportando linha {i + 1} de {dataGridView1.Rows.Count}..."; });
                                }

                                workbook.SaveAs(sfd.FileName);
                            }
                        });

                        messageBox.Close();

                        MessageBox.Show("Exportação para Excel concluída com sucesso!", "Informação", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Erro ao exportar para Excel: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void dataGridView1_MouseDown(object sender, MouseEventArgs e)
        {

        }
    }
 }

