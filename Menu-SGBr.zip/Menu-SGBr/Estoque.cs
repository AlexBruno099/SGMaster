﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FirebirdSql.Data.FirebirdClient;
using Menu_SGBr.Classes;
using Microsoft.EntityFrameworkCore;
using static Menu_SGBr.Classes.DataContext;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion.Internal;
using Menu_SGBr.Class;
using OfficeOpenXml;
using System.IO;
using ExcelDataReader;
using ClosedXML.Excel;


namespace Menu_SGBr
{
    public partial class estoque : Form
    {

        public estoque()
        {
            this.Width = Screen.PrimaryScreen.Bounds.Width;

            this.Height = 200;

            InitializeComponent();
            LoadDataAsync();

            ContextMenuStrip contextMenuStrip = new ContextMenuStrip();
            ToolStripMenuItem Importar = new ToolStripMenuItem("Importar Estoque .xls");
            ToolStripMenuItem Exportar = new ToolStripMenuItem("Exportar Estoque .xls");

            contextMenuStrip.Items.AddRange(new ToolStripItem[] { Importar, Exportar });

            Importar.Click += Importar_Click;
            Exportar.Click += Exportar_Click;

            this.ContextMenuStrip = contextMenuStrip;

            this.MouseDown += dataGridView1_MouseDown;

        }

        [DllImport("DwmApi")]
        private static extern int DwmSetWindowAttribute(IntPtr hwn, int attr, int[] attrValue, int attriSize);

        protected override void OnHandleCreated(EventArgs e)
        {
            if (DwmSetWindowAttribute(Handle, 19, new[] { 1 }, 4) != 0)
            {
                DwmSetWindowAttribute(Handle, 20, new[] { 1 }, 4);
            }
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        public async Task LoadDataAsync()
        {
            using (var SGcontext = new DataContext.SgContext())
            {
                var Produtos = await SGcontext.Estoque.Take(100).ToListAsync();

                DataTable dataTable = new DataTable();

                dataTable.Columns.Add("Codigo", typeof(string));
                dataTable.Columns.Add("Produto", typeof(string));
                dataTable.Columns.Add("CodBarras", typeof(string));
                dataTable.Columns.Add("Referencia", typeof(string));
                dataTable.Columns.Add("Unidade", typeof(string));
                dataTable.Columns.Add("PrecoCusto", typeof(decimal));
                dataTable.Columns.Add("PercLucro", typeof(decimal));
                dataTable.Columns.Add("PrecoVenda", typeof(decimal));
                dataTable.Columns.Add("CodGrupo", typeof(string));
                dataTable.Columns.Add("Grupo", typeof(string));
                dataTable.Columns.Add("CodFornecedor", typeof(string));
                dataTable.Columns.Add("Fornecedor", typeof(string));
                dataTable.Columns.Add("Tamanho", typeof(string));
                dataTable.Columns.Add("Peso", typeof(decimal));
                dataTable.Columns.Add("QtdeTotalComprada", typeof(decimal));
                dataTable.Columns.Add("QtdeTotalVendida", typeof(decimal));
                dataTable.Columns.Add("DataUltimaCompra", typeof(DateTime));
                dataTable.Columns.Add("DataUltimaVenda", typeof(DateTime));
                dataTable.Columns.Add("DataHoraCadastro", typeof(DateTime));
                dataTable.Columns.Add("QtdeMinima", typeof(decimal));
                dataTable.Columns.Add("QtdeMaxima", typeof(decimal));
                dataTable.Columns.Add("Qtde", typeof(decimal));
                dataTable.Columns.Add("Ativo", typeof(string));
                dataTable.Columns.Add("NCM", typeof(string));
                dataTable.Columns.Add("PercCreditoICMS", typeof(decimal));
                dataTable.Columns.Add("UsaGrade", typeof(string));
                dataTable.Columns.Add("UsaSerial", typeof(string));
                dataTable.Columns.Add("Origem", typeof(string));
                dataTable.Columns.Add("CodTributacaoIPI", typeof(string));
                dataTable.Columns.Add("TributacaoIPI", typeof(string));
                dataTable.Columns.Add("CodTributacaoPIS", typeof(string));
                dataTable.Columns.Add("TributacaoPIS", typeof(string));
                dataTable.Columns.Add("CodTributacaoCOFINS", typeof(string));
                dataTable.Columns.Add("TributacaoCOFINS", typeof(string));
                dataTable.Columns.Add("TipoTributacao", typeof(string));
                dataTable.Columns.Add("PercICMSInterna", typeof(decimal));
                dataTable.Columns.Add("PercMVAOriginal", typeof(decimal));
                dataTable.Columns.Add("PercICMSProprioST", typeof(decimal));
                dataTable.Columns.Add("IAT", typeof(string));
                dataTable.Columns.Add("IPPT", typeof(string));
                dataTable.Columns.Add("CSOSNCST", typeof(string));
                dataTable.Columns.Add("DescricaoCSOSNCST", typeof(string));
                dataTable.Columns.Add("Pesado", typeof(string));
                dataTable.Columns.Add("BaseCalculoICMSRetido", typeof(decimal));
                dataTable.Columns.Add("ValorICMSRetido", typeof(decimal));
                dataTable.Columns.Add("AliquotaICMSECF", typeof(decimal));
                dataTable.Columns.Add("MensagemNFE", typeof(string));
                dataTable.Columns.Add("CodMensagemNFE", typeof(string));
                dataTable.Columns.Add("CodUnidadeMedida", typeof(string));
                dataTable.Columns.Add("CodAplicacaoProduto", typeof(string));
                dataTable.Columns.Add("AplicacaoProduto", typeof(string));
                dataTable.Columns.Add("QtdeInicial", typeof(decimal));
                dataTable.Columns.Add("AliquotaISS", typeof(decimal));
                dataTable.Columns.Add("CodImpostoMedio", typeof(string));
                dataTable.Columns.Add("PercImpostoMedio", typeof(decimal));
                dataTable.Columns.Add("CodCSTOrigem", typeof(string));
                dataTable.Columns.Add("CodEmitente", typeof(string));
                dataTable.Columns.Add("ValidadeProduto", typeof(DateTime));
                dataTable.Columns.Add("FatorConversao", typeof(string));
                dataTable.Columns.Add("TributacaoServico", typeof(string));
                dataTable.Columns.Add("ReducaoBaseCalculoServico", typeof(string));
                dataTable.Columns.Add("Status", typeof(string));
                dataTable.Columns.Add("DescricaoComplementar", typeof(string));
                dataTable.Columns.Add("PrecoVendaUSS", typeof(string));
                dataTable.Columns.Add("PercMaximoDesconto", typeof(string));
                dataTable.Columns.Add("ValorComissaoFixo", typeof(string));
                dataTable.Columns.Add("PercComissao", typeof(string));
                dataTable.Columns.Add("PrecoMinimoUSS", typeof(string));
                dataTable.Columns.Add("PrecoMinimo", typeof(string));
                dataTable.Columns.Add("CodCompra", typeof(string));
                dataTable.Columns.Add("ValorConversao", typeof(string));
                dataTable.Columns.Add("ValorFrete", typeof(string));
                dataTable.Columns.Add("ValorOutros", typeof(string));
                dataTable.Columns.Add("ValorICMSST", typeof(string));
                dataTable.Columns.Add("ValorIPI", typeof(string));
                dataTable.Columns.Add("ValorUnitarioCompra", typeof(string));
                dataTable.Columns.Add("PercPIS", typeof(string));
                dataTable.Columns.Add("PercCOFINS", typeof(string));
                dataTable.Columns.Add("Campo1", typeof(string));
                dataTable.Columns.Add("Campo2", typeof(string));
                dataTable.Columns.Add("Campo3", typeof(string));
                dataTable.Columns.Add("Campo4", typeof(string));
                dataTable.Columns.Add("Campo5", typeof(string));
                dataTable.Columns.Add("Campo6", typeof(string));
                dataTable.Columns.Add("Campo7", typeof(string));
                dataTable.Columns.Add("Campo8", typeof(string));
                dataTable.Columns.Add("Campo9", typeof(string));
                dataTable.Columns.Add("Campo10", typeof(string));
                dataTable.Columns.Add("Marca", typeof(string));
                dataTable.Columns.Add("PercReducaoBC", typeof(string));
                dataTable.Columns.Add("PercReducaoBCST", typeof(string));
                dataTable.Columns.Add("CodSubgrupo", typeof(string));
                dataTable.Columns.Add("Subgrupo", typeof(string));
                dataTable.Columns.Add("ControlarValidade", typeof(string));
                dataTable.Columns.Add("CodMarca", typeof(string));
                dataTable.Columns.Add("PrecoRevenda", typeof(string));
                dataTable.Columns.Add("PercIPI", typeof(string));
                dataTable.Columns.Add("CFOP", typeof(string));
                dataTable.Columns.Add("UNConversaoVenda", typeof(string));
                dataTable.Columns.Add("ValorConversaoVenda", typeof(string));
                dataTable.Columns.Add("CodTabelaPreco", typeof(string));
                dataTable.Columns.Add("TabelaPreco", typeof(string));
                dataTable.Columns.Add("PercImpostoEstadual", typeof(string));
                dataTable.Columns.Add("PercImpostoMunicipal", typeof(string));
                dataTable.Columns.Add("CodEnquadramentoIPI", typeof(string));
                dataTable.Columns.Add("CEST", typeof(string));
                dataTable.Columns.Add("QtdeEmProducao", typeof(string));
                dataTable.Columns.Add("QtdePedidoDeVenda", typeof(string));
                dataTable.Columns.Add("QtdePedidoDeCompra", typeof(string));
                dataTable.Columns.Add("QtdeReservada", typeof(string));
                dataTable.Columns.Add("QtdeReal", typeof(string));
                dataTable.Columns.Add("QtdeEmProducaoMP", typeof(string));
                dataTable.Columns.Add("UnidadeMedidaEtiqueta", typeof(string));
                dataTable.Columns.Add("FatorConversaoEtiqueta", typeof(string));
                dataTable.Columns.Add("CodANP", typeof(string));
                dataTable.Columns.Add("DescricaoANP", typeof(string));
                dataTable.Columns.Add("PercGLP", typeof(string));
                dataTable.Columns.Add("PercGNN", typeof(string));
                dataTable.Columns.Add("PercGNI", typeof(string));
                dataTable.Columns.Add("ValorPartida", typeof(string));
                dataTable.Columns.Add("SeloIPI", typeof(string));
                dataTable.Columns.Add("AliquotaFCP", typeof(string));
                dataTable.Columns.Add("PercFCP", typeof(string));
                dataTable.Columns.Add("CNPJFabricante", typeof(string));
                dataTable.Columns.Add("CodBeneficioFiscal", typeof(string));
                dataTable.Columns.Add("CodANVISA", typeof(string));
                dataTable.Columns.Add("CodUNTrib", typeof(string));
                dataTable.Columns.Add("UNTrib", typeof(string));
                dataTable.Columns.Add("QtdeTrib", typeof(string));
                dataTable.Columns.Add("DesmontarNaVenda", typeof(string));
                dataTable.Columns.Add("AliquotaICMSSTRetido", typeof(string));
                dataTable.Columns.Add("ValorBCICMSSTRetido", typeof(string));
                dataTable.Columns.Add("AliquotaICMSEfetivo", typeof(string));
                dataTable.Columns.Add("PercICMSEfetivo", typeof(string));
                dataTable.Columns.Add("ValorBCICMSEfetivo", typeof(string));
                dataTable.Columns.Add("ValorICMSEfetivo", typeof(string));
                dataTable.Columns.Add("ValorBCICMSSubstituto", typeof(string));
                dataTable.Columns.Add("ValorICMSSTRetido", typeof(string));
                dataTable.Columns.Add("CodBarrasCaixa", typeof(string));
                dataTable.Columns.Add("ValorPMC", typeof(string));
                dataTable.Columns.Add("EnviarDados", typeof(string));
                dataTable.Columns.Add("ValorFCPST", typeof(string));
                dataTable.Columns.Add("Localizacao", typeof(string));
                dataTable.Columns.Add("CodBarrasInterno", typeof(string));
                dataTable.Columns.Add("CodBarrasTributavel", typeof(string));
                dataTable.Columns.Add("Vacina", typeof(string));
                dataTable.Columns.Add("PercDescontoCaixa", typeof(string));
                dataTable.Columns.Add("PercCashback", typeof(string));
                dataTable.Columns.Add("TipoBarra", typeof(string));

                foreach (var prod in Produtos)
                {
                    dataTable.Rows.Add(
                        prod.Controle,
                        prod.Produto,
                        prod.CodBarras,
                        prod.Referencia,
                        prod.Unidade,
                        prod.PrecoCusto,
                        prod.PercLucro,
                        prod.PrecoVenda,
                        prod.CodGrupo,
                        prod.Grupo,
                        prod.CODFORNECEDOR,
                        prod.Fornecedor,
                        prod.Tamanho,
                        prod.Peso,
                        prod.QTDETotalComprada,
                        prod.QTDETotalVendida,
                        prod.DataUltimaCompra,
                        prod.DataUltimaVenda,
                        prod.DataHoraCadastro,
                        prod.QTDEMinima,
                        prod.QTDEMaxima,
                        prod.QTDE,
                        prod.Ativo,
                        prod.NCM,
                        prod.Percreditocicms,
                        prod.UsaGrade,
                        prod.UsaSerial,
                        prod.Origem,
                        prod.CodTributacaoIPI,
                        prod.TributacaoIPI,
                        prod.CodTributacaoPIS,
                        prod.TributacaoPis,
                        prod.CodTributacaoCofins,
                        prod.TributacaoCofins,
                        prod.TipoTributação,
                        prod.PercIcmsStInterna,
                        prod.PercMvaOriginal,
                        prod.PercIcmsProprioSt,
                        prod.IAT,
                        prod.IPPT,
                        prod.CSOSN,
                        prod.DescricaoCSOSN,
                        prod.Pesado,
                        prod.BaseCalculoIcmsStRetido,
                        prod.VALORICMSSTRETIDO,
                        prod.AliquotaIcmsEcf,
                        prod.MensagemNfe,
                        prod.CodMensagemNfe,
                        prod.CodUnidadeMedida,
                        prod.CodAplicacaoProduto,
                        prod.AplicacaoProduto,
                        prod.QTDEInicial,
                        prod.AliquotaISS,
                        prod.CODIMPOSTOMEDIO,
                        prod.PercImpostoMedio,
                        prod.CodCstOrigem,
                        prod.CodEmitente,
                        prod.DiasValidadeProduto,
                        prod.FatorConversao,
                        prod.TributaçãoServiço,
                        prod.ReduçãoBaseCalculoServiço,
                        prod.Status,
                        prod.DescriçãoComplementar,
                        prod.PrecoVendaUss,
                        prod.PercentualMaximoDesconto,
                        prod.ValorComissaoFixo,
                        prod.PercComissao,
                        prod.PrecoMinimoUss,
                        prod.PrecoMinimo,
                        prod.CodCompra,
                        prod.ValorConversao,
                        prod.ValorFrete,
                        prod.ValorOutros,
                        prod.VALORICMSEFET,
                        prod.ValorIpi,
                        prod.ValorUnitarioCompra,
                        prod.PercPis,
                        prod.PercCofins,
                        prod.Campo1,
                        prod.Campo2,
                        prod.Campo3,
                        prod.Campo4,
                        prod.Campo5,
                        prod.Campo6,
                        prod.Campo7,
                        prod.Campo8,
                        prod.Campo9,
                        prod.Campo10,
                        prod.Marca,
                        prod.PercReducaoBC,
                        prod.PercReducaoBCST,
                        prod.CodSubGrupo,
                        prod.Grupo,
                        prod.ControlarValidade,
                        prod.CodMarca,
                        prod.PrecoRevenda,
                        prod.PercIpi,
                        prod.Cfop,
                        prod.UnidadeConversaoVenda,
                        prod.ValorConversaoVenda,
                        prod.CodTabelaPreco,
                        prod.NomeTabelaPreco,
                        prod.PercImpostoMedio,
                        prod.PercImpostoMedioMunicipal,
                        prod.CódigoEnquadramento,
                        prod.Cest,
                        prod.QtdeEmProducao,
                        prod.QtdePedidoVenda,
                        prod.QtdePedidoCompra,
                        prod.QtdeReservada,
                        prod.QtdeReal,
                        prod.QtdeEmProducao,
                        prod.UnidadeMedidaEtiqueta,
                        prod.FatorConversaoEtiqueta,
                        prod.CodigoAnp,
                        prod.DESCRICAOANP,
                        prod.PERCGLPCOMB,
                        prod.PERCGNNCOMB,
                        prod.PERCGNICOMB,
                        prod.VALORPARTIDACOMB,
                        prod.SeloIpi,
                        prod.ALIQUOTAFCP,
                        prod.PERCFCPST,
                        prod.CNPJFABRICANTE,
                        prod.CODBENEFICIOFISCAL,
                        prod.CODIGOANVISA,
                        prod.CODUNIDADETRIBUTAVEL,
                        prod.UNIDADETRIBUTAVEL,
                        prod.QTDETRIBUTAVEL,
                        prod.DESMONTARNAVENDA,
                        prod.ALIQUOTAICMSEFET,
                        prod.VALORBCICMSSTRET,
                        prod.ALIQUOTAICMSEFET,
                        prod.PERCREDUCAOICMSEFET,
                        prod.BaseCalculoIcmsStRetido,
                        prod.VALORBCICMSEFET,
                        prod.VALORICMSSUBSTITUTO,
                        prod.VALORICMSSTRETIDO,
                        prod.CODBARRASCAIXA,
                        prod.VALORPMC,
                        prod.ENVIARDADOS,
                        prod.VALORFCPST,
                        prod.LOCALIZACAO,
                        prod.CODBARRASINTERNO,
                        prod.CODBARRASTRIB,
                        prod.VACINA,
                        prod.PERCDESCONTOCAIXA,
                        prod.PERCCASHBACK,
                        prod.TipoBarra
                    );
                }

                if (dataGridView1.InvokeRequired)
                {
                    dataGridView1.Invoke(new Action(() => dataGridView1.DataSource = dataTable));
                }
                else
                {
                    dataGridView1.DataSource = dataTable;
                }
            }
        }
        private async void LoadData()
        {
            await LoadDataAsync();
        }
        private static List<Estoque> ReadXls(string filePath)
        {
            var response = new List<Estoque>();
            FileInfo existingFile = new FileInfo(filePath);
            if (!existingFile.Exists)
            {
                throw new FileNotFoundException("O arquivo Excel especificado não foi encontrado.", existingFile.FullName);
            }

            System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);
            using (var stream = File.Open(filePath, FileMode.Open, FileAccess.Read))
            {
                using (var reader = ExcelReaderFactory.CreateReader(stream))
                {
                    var result = reader.AsDataSet(new ExcelDataSetConfiguration()
                    {
                        ConfigureDataTable = (_) => new ExcelDataTableConfiguration()
                        {
                            UseHeaderRow = true
                        }
                    });

                    DataTable table = result.Tables[0];

                    var requiredColumns = new[] { "Descrição" };
                    foreach (var column in requiredColumns)
                    {
                        if (!table.Columns.Contains(column))
                        {
                            MessageBox.Show($"Coluna obrigatória '{column}' não foi encontrada.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return response;
                        }
                    }

                    foreach (DataRow row in table.Rows)
                    {
                        var estoque = new Estoque();
                        estoque.Produto = row["Descrição"].ToString();
                        estoque.Referencia = row["Referência"].ToString();
                        estoque.Unidade = row["Qtde inicial"].ToString();
                        estoque.CodBarras = row["Código de barras"].ToString();

                        if (!int.TryParse(row["Preço de custo"].ToString(), out int PrecoCusto))
                        {
                            MessageBox.Show($"Valor inválido para 'Preço de custo' na linha {table.Rows.IndexOf(row) + 5}.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return response;
                        }
                        estoque.PrecoCusto = PrecoCusto;

                        if (!int.TryParse(row["Preço de venda"].ToString(), out int PrecoVenda))
                        {
                            MessageBox.Show($"Valor inválido para 'Preço de venda' na linha {table.Rows.IndexOf(row) + 6}.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return response;
                        }
                        estoque.PrecoVenda = PrecoVenda;

                        estoque.CSOSN = row["CSOSN/CST"].ToString();

                        if (!int.TryParse(row["Alíquota ECF"].ToString(), out int AliqEcf))
                        {
                            MessageBox.Show($"Valor inválido para 'Preço de venda' na linha {table.Rows.IndexOf(row) + 8}.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return response;
                        }
                        estoque.AliquotaIcmsEcf = AliqEcf;
                        estoque.CodTributacaoIPI = row["CST IPI"].ToString();

                        estoque.CodTributacaoPIS = row["CST PIS"].ToString();

                        estoque.CodTributacaoCofins = row["CST COFINS"].ToString();

                        estoque.NCM = row["NCM"].ToString();
                        response.Add(estoque);
                    }
                }
            }

            return response;
        }

        private async void importarXlsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Filter = "Excel Files|*.xls;*.xlsx",
                Title = "Selecione um arquivo Excel"
            };
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string filePath = openFileDialog.FileName;
                try
                {
                    var messageBox = new Form { Text = "Progresso de Importação", Size = new Size(300, 100), StartPosition = FormStartPosition.CenterScreen };
                    var label = new Label { Text = "Iniciando a leitura do arquivo Excel...", Dock = DockStyle.Top };
                    var progressBar = new ProgressBar { Style = ProgressBarStyle.Continuous, Dock = DockStyle.Bottom };
                    messageBox.Controls.Add(progressBar);
                    messageBox.Controls.Add(label);
                    messageBox.Show();

                    List<Estoque> estoques = ReadXls(filePath);
                    progressBar.Maximum = estoques.Count;

                    if (estoques.Count > 0)
                    {
                        using (var context = new SgContext())
                        {

                            foreach (var est in estoques)
                            {
                                if (est.PercLucro == null)
                                {
                                    est.PercLucro = 0;
                                }
                                if (est.CodUnidadeMedida == null)
                                {
                                    est.CodUnidadeMedida = (context.Estoque.Max(estq => (int?)estq.CodUnidadeMedida) ?? 0) + 1;
                                }
                                if (est.CodCstOrigem == null)
                                {
                                    est.CodCstOrigem = (context.Estoque.Max(estq => (int?)estq.CodCstOrigem) ?? 0) + 1;
                                }
                                if (est.FatorConversao == null)
                                {
                                    est.FatorConversao = "*";
                                }
                                if (est.IAT == null)
                                {
                                    est.IAT = "A";
                                }
                                if (est.IPPT == null)
                                {
                                    est.IPPT = "T";
                                }
                                if (est.Tributado == null)
                                {
                                    est.Tributado = "Sim";
                                }
                                if (est.Pesado == null)
                                {
                                    est.Pesado = "Não";
                                }
                                try
                                {
                                    context.ChangeTracker.AutoDetectChangesEnabled = false;

                                    var removeConstraintSql = @"
                                        DECLARE @constraint_name NVARCHAR(128);
                                        SELECT @constraint_name = CONSTRAINT_NAME
                                        FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS
                                        WHERE CONSTRAINT_TYPE = 'FOREIGN KEY'
                                        AND TABLE_NAME = 'testoque'
                                        AND CONSTRAINT_NAME = 'FK_TESTOQUE_3';

                                        IF @constraint_name IS NOT NULL
                                        BEGIN
                                            EXEC ('ALTER TABLE testoque DROP CONSTRAINT ' || @constraint_name);
                                        END";

                                    await context.Database.ExecuteSqlRawAsync(removeConstraintSql);

                                    await context.SaveChangesAsync();

                                    var addConstraintSql = @"
                                        ALTER TABLE testoque ADD CONSTRAINT FK_TESTOQUE_3 
                                        FOREIGN KEY (CODUNIDADEMEDIDA) REFERENCES UnidadeMedida(CODUNIDADEMEDIDA);";

                                    await context.Database.ExecuteSqlRawAsync(addConstraintSql);

                                    context.ChangeTracker.AutoDetectChangesEnabled = true;
                                }
                                catch (DbUpdateException ex)
                                {
                                    var innerException = ex.InnerException;
                                    while (innerException?.InnerException != null)
                                    {
                                        innerException = innerException.InnerException;
                                    }
                                   
                                }
                                catch (Exception ex)
                                {
                                    
                                }

                                var existingEstoque = await context.Estoque
                                    .AsNoTracking()
                                    .FirstOrDefaultAsync(estq => estq.Produto == est.Produto);

                                if (existingEstoque == null)
                                {
                                    est.Ativo = "S";
                                    est.Controle = context.Estoque.Max(f => (int?)f.Controle) + 1 ?? 1;
                                    context.Estoque.Add(est);
                                }
                                else
                                {
                                    est.Controle = existingEstoque.Controle;
                                    context.Entry(existingEstoque).CurrentValues.SetValues(est);
                                }
                            }
                            await context.SaveChangesAsync();
                        }
                        MessageBox.Show("Produtos importados e salvos no banco de dados com sucesso.", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        using (var context = new SgContext())
                        {
                            dataGridView1.DataSource = context.fornecedor.ToList();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Nenhum Produto encontrado no arquivo.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
                catch (DbUpdateException ex)
                {
                    var innerException = ex.InnerException;
                    while (innerException?.InnerException != null)
                    {
                        innerException = innerException.InnerException;
                    }
                    MessageBox.Show($"Erro ao importar o arquivo: {innerException?.Message ?? ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Erro ao importar o arquivo: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void mostrarToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void sairToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }


        private async void pictureBox1_Click(object sender, EventArgs e)
        {
            if (BuscaBox.Checked)
            {
                try
                {
                    using (var SGcontex = new DataContext.SgContext())
                    {
                        await SGcontex.Database.OpenConnectionAsync();

                        string selectSql = "SELECT * FROM TESTOQUE";

                        using (FbDataAdapter dataAdapter = new FbDataAdapter(selectSql, (FbConnection)SGcontex.Database.GetDbConnection()))
                        {
                            DataTable dataTable = new DataTable();

                            await Task.Run(() => dataAdapter.Fill(dataTable));

                            if (dataGridView1.InvokeRequired)
                            {
                                dataGridView1.Invoke(new Action(() => dataGridView1.DataSource = dataTable));
                            }
                            else
                            {
                                dataGridView1.DataSource = dataTable;
                            }
                        }
                    }
                }
                catch (Exception ex)
                {

                }
            }
            else
            {

            }
        }

        private void dataGridView1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                this.ContextMenuStrip.Show(this, new System.Drawing.Point(e.X, e.Y));
            }
        }

        private async void Importar_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Filter = "Excel Files|*.xls;*.xlsx",
                Title = "Selecione um arquivo Excel"
            };
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string filePath = openFileDialog.FileName;
                try
                {
                    var messageBox = new Form { Text = "Progresso de Importação", Size = new Size(300, 100), StartPosition = FormStartPosition.CenterScreen };
                    var label = new Label { Text = "Iniciando a leitura do arquivo Excel...", Dock = DockStyle.Top };
                    var progressBar = new ProgressBar { Style = ProgressBarStyle.Continuous, Dock = DockStyle.Bottom };
                    messageBox.Controls.Add(progressBar);
                    messageBox.Controls.Add(label);
                    messageBox.Show();

                    List<Estoque> estoques = ReadXls(filePath);
                    progressBar.Maximum = estoques.Count;

                    if (estoques.Count > 0)
                    {
                        using (var context = new SgContext())
                        {
                            foreach (var est in estoques)
                            {
                                if (est.PercLucro == null)
                                {
                                    est.PercLucro = 0;
                                }
                                if (est.CodUnidadeMedida == null)
                                {
                                    est.CodUnidadeMedida = (context.Estoque.Max(estq => (int?)estq.CodUnidadeMedida) ?? 0) + 1;
                                }
                                if (est.CodCstOrigem == null)
                                {
                                    est.CodCstOrigem = (context.Estoque.Max(estq => (int?)estq.CodCstOrigem) ?? 0) + 1;
                                }
                                if (est.FatorConversao == null)
                                {
                                    est.FatorConversao = "*";
                                }
                                if (est.IAT == null)
                                {
                                    est.IAT = "A";
                                }
                                if (est.IPPT == null)
                                {
                                    est.IPPT = "T";
                                }
                                if (est.Tributado == null)
                                {
                                    est.Tributado = "Sim";
                                }
                                if (est.Pesado == null)
                                {
                                    est.Pesado = "Não";
                                }
                                try
                                {
                                    context.ChangeTracker.AutoDetectChangesEnabled = false;

                                    var removeConstraintSql = @"
                                        DECLARE @constraint_name NVARCHAR(128);
                                        SELECT @constraint_name = CONSTRAINT_NAME
                                        FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS
                                        WHERE CONSTRAINT_TYPE = 'FOREIGN KEY'
                                        AND TABLE_NAME = 'testoque'
                                        AND CONSTRAINT_NAME = 'FK_TESTOQUE_3';

                                        IF @constraint_name IS NOT NULL
                                        BEGIN
                                            EXEC ('ALTER TABLE testoque DROP CONSTRAINT ' || @constraint_name);
                                        END";

                                    await context.Database.ExecuteSqlRawAsync(removeConstraintSql);

                                    await context.SaveChangesAsync();

                                    var addConstraintSql = @"
                                        ALTER TABLE testoque ADD CONSTRAINT FK_TESTOQUE_3 
                                        FOREIGN KEY (CODUNIDADEMEDIDA) REFERENCES UnidadeMedida(CODUNIDADEMEDIDA);";

                                    await context.Database.ExecuteSqlRawAsync(addConstraintSql);

                                    context.ChangeTracker.AutoDetectChangesEnabled = true;
                                }
                                catch (DbUpdateException ex)
                                {
                                    var innerException = ex.InnerException;
                                    while (innerException?.InnerException != null)
                                    {
                                        innerException = innerException.InnerException;
                                    }
                                }
                                catch (Exception ex)
                                {

                                }

                                var existingEstoque = await context.Estoque
                                    .AsNoTracking()
                                    .FirstOrDefaultAsync(estq => estq.Produto == est.Produto);

                                if (existingEstoque == null)
                                {
                                    est.Ativo = "S";
                                    est.Controle = context.Estoque.Max(f => (int?)f.Controle) + 1 ?? 1;
                                    context.Estoque.Add(est);
                                }
                                else
                                {
                                    est.Controle = existingEstoque.Controle;
                                    context.Entry(existingEstoque).CurrentValues.SetValues(est);
                                }

                                await context.SaveChangesAsync();

                                progressBar.Value++;
                            }

                            await context.SaveChangesAsync();
                        }

                        MessageBox.Show("Produtos importados e salvos no banco de dados com sucesso.", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        using (var context = new SgContext())
                        {
                            dataGridView1.DataSource = context.fornecedor.ToList();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Nenhum Produto encontrado no arquivo.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
                catch (DbUpdateException ex)
                {
                    var innerException = ex.InnerException;
                    while (innerException?.InnerException != null)
                    {
                        innerException = innerException.InnerException;
                    }
                    MessageBox.Show($"Erro ao importar o arquivo: {innerException?.Message ?? ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Erro ao importar o arquivo: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }




        private async void Exportar_Click(object sender, EventArgs e)
        {
            using (SaveFileDialog sfd = new SaveFileDialog() { Filter = "Excel Workbook|*.xlsx" })
            {
                if (sfd.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        var messageBox = new Form { Text = "Progresso de Exportação", Size = new Size(300, 100), StartPosition = FormStartPosition.CenterScreen };
                        var label = new Label { Text = "Iniciando a exportação para Excel...", Dock = DockStyle.Top };
                        var progressBar = new ProgressBar { Style = ProgressBarStyle.Continuous, Dock = DockStyle.Bottom };
                        messageBox.Controls.Add(progressBar);
                        messageBox.Controls.Add(label);
                        messageBox.Show();

                        await Task.Run(() =>
                        {
                            using (var workbook = new XLWorkbook())
                            {
                                var worksheet = workbook.Worksheets.Add("Sheet1");

                                progressBar.Invoke((MethodInvoker)delegate { progressBar.Maximum = dataGridView1.Rows.Count; });

                                for (int i = 0; i < dataGridView1.Columns.Count; i++)
                                {
                                    worksheet.Cell(1, i + 1).Value = dataGridView1.Columns[i].HeaderText;
                                }

                                for (int i = 0; i < dataGridView1.Rows.Count; i++)
                                {
                                    for (int j = 0; j < dataGridView1.Columns.Count; j++)
                                    {
                                        worksheet.Cell(i + 2, j + 1).Value = dataGridView1.Rows[i].Cells[j].Value?.ToString();
                                    }

                                    progressBar.Invoke((MethodInvoker)delegate { progressBar.Value = i + 1; });
                                    label.Invoke((MethodInvoker)delegate { label.Text = $"Exportando linha {i + 1} de {dataGridView1.Rows.Count}..."; });
                                }

                                workbook.SaveAs(sfd.FileName);
                            }
                        });

                        messageBox.Close();

                        MessageBox.Show("Exportação para Excel concluída com sucesso!", "Informação", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Erro ao exportar para Excel: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

    }
}



