﻿using System;
using System.Collections.Generic;
using FirebirdSql.Data.FirebirdClient;
using Microsoft.EntityFrameworkCore;
using Menu_SGBr.Classes;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Menu_SGBr.Class;
using Menu_SGBr.Table;
using System.IO;
using System.Windows.Forms;

namespace Menu_SGBr.Classes
{
    public class DataContext
    {
        public static class ConnectionParams
        {
            public static string ConnectionString(string configSoftMaster)
            {
                string caminhoBancoDados = "C:\\SGBR\\Master\\ConfigSoftMaster.ini";

                if (File.Exists(configSoftMaster))
                {
                    string[] linhas = File.ReadAllLines(configSoftMaster);
                    foreach (string linha in linhas)
                    {
                        if (linha.StartsWith("Conexao="))
                        {
                            caminhoBancoDados = linha.Substring("Conexao=".Length);
                            break;
                        }
                    }

                    if (string.IsNullOrEmpty(caminhoBancoDados))
                    {
                        throw new Exception("Banco de dados não encontrado");
                    }
                }
                else
                {
                    throw new FileNotFoundException("Arquivo ConfigSoftMaster não encontrado", configSoftMaster);
                }

                return $"DataSource=localhost;Database={caminhoBancoDados};Port=3050;User=SYSDBA;Password=masterkey;Charset=UTF8;Dialect=3;Connection lifetime=15;PacketSize=8192;ServerType=0;Unicode=True;Max Pool Size=1000";
            }
        }

        public class SgContext : DbContext
        {
            public DbSet<Cliente> cliente { get; set; }
            public DbSet<Fornecedor> fornecedor { get; set; }
            public DbSet<Estoque> Estoque { get; set; }
            public DbSet<Emitente> emitente { get; set; }
            
            protected override void OnModelCreating(ModelBuilder modelBuilder)
            {
                base.OnModelCreating(modelBuilder);
                new ClienteEntityTypeConfiguration().Configure(modelBuilder.Entity<Cliente>());
                new FornecedorEntityTypeConfiguration().Configure(modelBuilder.Entity<Fornecedor>());
                new EstoqueEntityTypeConfiguration().Configure(modelBuilder.Entity<Estoque>());
                new EmitenteEntityTypeConfiguration().Configure(modelBuilder.Entity<Emitente>());
            }

            protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
            {
                base.OnConfiguring(optionsBuilder);
                string configSoftMaster = "C:\\SGBR\\Master\\ConfigSoftMaster.ini";
                optionsBuilder.UseFirebird(ConnectionParams.ConnectionString(configSoftMaster));
            }
        }
    }
}
