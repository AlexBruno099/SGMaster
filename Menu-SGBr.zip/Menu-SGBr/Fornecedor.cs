﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FirebirdSql.Data.FirebirdClient;
using Menu_SGBr.Classes;
using Microsoft.EntityFrameworkCore;
using static Menu_SGBr.Classes.DataContext;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion.Internal;
using Menu_SGBr.Class;
using ExcelDataReader;
using System.IO;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;
using System.Data.SqlClient;
using System.Security.Cryptography.X509Certificates;
using OfficeOpenXml;
using System.Runtime.Remoting.Contexts;
using System.Linq;
using OfficeOpenXml.Style;
using NPOI.SS.UserModel;
using ClosedXML;
using ClosedXML.Excel;
using DocumentFormat.OpenXml.Vml;

namespace Menu_SGBr
{
    public partial class Fornecedores : Form
    {

        public Fornecedores()
        {
            this.Width = Screen.PrimaryScreen.Bounds.Width;

            this.Height = 200;

            InitializeComponent();
            LoadDataAsync();

            ContextMenuStrip contextMenuStrip = new ContextMenuStrip();
            ToolStripMenuItem Importar = new ToolStripMenuItem("Importar Fornecedores .xls");
            ToolStripMenuItem Exportar = new ToolStripMenuItem("Exportar Fornecedores .xls");

            contextMenuStrip.Items.AddRange(new ToolStripItem[] { Importar, Exportar });

            Importar.Click += Importar_Click;
            Exportar.Click += Exportar_Click;

            this.ContextMenuStrip = contextMenuStrip;

            this.MouseDown += Fornecedores_MouseDown;
        }

        [DllImport("DwmApi")]
        private static extern int DwmSetWindowAttribute(IntPtr hwn, int attr, int[] attrValue, int attriSize);

        protected override void OnHandleCreated(EventArgs e)
        {
            if (DwmSetWindowAttribute(Handle, 19, new[] { 1 }, 4) != 0)
            {
                DwmSetWindowAttribute(Handle, 20, new[] { 1 }, 4);
            }
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        public async Task LoadDataAsync()
        {
            using (var SGcontext = new DataContext.SgContext())
            {
                var fornecedores = await SGcontext.fornecedor.Take(100).ToListAsync();

                DataTable dataTable = new DataTable();

                dataTable.Columns.Add("Codigo", typeof(string));
                dataTable.Columns.Add("NomeFantasia", typeof(string));
                dataTable.Columns.Add("RazaoSocial", typeof(string));
                dataTable.Columns.Add("CPF", typeof(string));
                dataTable.Columns.Add("RG", typeof(string));
                dataTable.Columns.Add("CNPJ", typeof(string));
                dataTable.Columns.Add("Celular", typeof(string));
                dataTable.Columns.Add("Telefone", typeof(string));
                dataTable.Columns.Add("Pais", typeof(string));
                dataTable.Columns.Add("UF", typeof(string));
                dataTable.Columns.Add("CodCidade", typeof(string));
                dataTable.Columns.Add("Cidade", typeof(string));
                dataTable.Columns.Add("Bairro", typeof(string));
                dataTable.Columns.Add("Endereco", typeof(string));
                dataTable.Columns.Add("CEP", typeof(string));
                dataTable.Columns.Add("Numero", typeof(string));
                dataTable.Columns.Add("Complemento", typeof(string));
                dataTable.Columns.Add("IE", typeof(string));
                dataTable.Columns.Add("IM", typeof(string));
                dataTable.Columns.Add("SAC", typeof(string));
                dataTable.Columns.Add("Email", typeof(string));
                dataTable.Columns.Add("Site", typeof(string));
                dataTable.Columns.Add("FormaPagamento", typeof(string));
                dataTable.Columns.Add("NomeContatoJuridica", typeof(string));
                dataTable.Columns.Add("DataHoraCadastro", typeof(DateTime));
                dataTable.Columns.Add("Campo1", typeof(string));
                dataTable.Columns.Add("Campo2", typeof(string));
                dataTable.Columns.Add("Campo3", typeof(string));
                dataTable.Columns.Add("Campo4", typeof(string));
                dataTable.Columns.Add("Campo5", typeof(string));
                dataTable.Columns.Add("Campo6", typeof(string));
                dataTable.Columns.Add("Campo7", typeof(string));
                dataTable.Columns.Add("Campo8", typeof(string));
                dataTable.Columns.Add("Campo9", typeof(string));
                dataTable.Columns.Add("Campo10", typeof(string));
                dataTable.Columns.Add("CodCidadeIBGE", typeof(string));
                dataTable.Columns.Add("Ativo", typeof(string));

                foreach (var fornecedor in fornecedores)
                {
                    dataTable.Rows.Add(
                        fornecedor.Controle,
                        fornecedor.NomeFantasia,
                        fornecedor.RazaoSocial,
                        fornecedor.CPF,
                        fornecedor.RG,
                        fornecedor.CNPJ,
                        fornecedor.Celular,
                        fornecedor.Telefone,
                        fornecedor.Pais,
                        fornecedor.UF,
                        fornecedor.CodCidade,
                        fornecedor.Cidade,
                        fornecedor.Bairro,
                        fornecedor.Endereco,
                        fornecedor.CEP,
                        fornecedor.Numero,
                        fornecedor.Complemento,
                        fornecedor.IE,
                        fornecedor.IM,
                        fornecedor.SAC,
                        fornecedor.Email,
                        fornecedor.Site,
                        fornecedor.FormaPagamento,
                        fornecedor.NomeContatoJuridica,
                        fornecedor.DataHoraCadastro,
                        fornecedor.Campo1,
                        fornecedor.Campo2,
                        fornecedor.Campo3,
                        fornecedor.Campo4,
                        fornecedor.Campo5,
                        fornecedor.Campo6,
                        fornecedor.Campo7,
                        fornecedor.Campo8,
                        fornecedor.Campo9,
                        fornecedor.Campo10,
                        fornecedor.CodigoCidadeIBGE,
                        fornecedor.Ativo
                    );
                }

                if (dataGridView1.InvokeRequired)
                {
                    dataGridView1.Invoke(new Action(() => dataGridView1.DataSource = dataTable));
                }
                else
                {
                    dataGridView1.DataSource = dataTable;
                }
            }
        }
            private async void LoadData()
        {
            await LoadDataAsync();
        }
        private static List<Fornecedor> ReadXls(string filePath)
        {
            var response = new List<Fornecedor>();
            FileInfo existingFile = new FileInfo(filePath);

            if (!existingFile.Exists)
            {
                throw new FileNotFoundException("O arquivo Excel especificado não foi encontrado.", existingFile.FullName);
            }

            System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);

            try
            {
                using (var stream = File.Open(filePath, FileMode.Open, FileAccess.Read))
                {
                    using (var reader = ExcelReaderFactory.CreateReader(stream))
                    {
                        var result = reader.AsDataSet(new ExcelDataSetConfiguration()
                        {
                            ConfigureDataTable = (_) => new ExcelDataTableConfiguration()
                            {
                                UseHeaderRow = true
                            }
                        });

                        DataTable table = result.Tables[0];

                        var requiredColumns = new[] { "Cliente/Fornecedor", "Fantasia", "CPF", "RG/IE", "Endereço", "Complemento", "Bairro", "CEP", "Número", "UF", "Telefone/Celular", "E-mail" };
                        var missingColumns = requiredColumns.Where(column => !table.Columns.Contains(column)).ToList();

                        if (missingColumns.Any())
                        {
                            string missingColumnsMessage = string.Join(", ", missingColumns);
                            throw new Exception($"Coluna(s) obrigatória(s) não encontrada(s): {missingColumnsMessage}.");
                        }

                        foreach (DataRow row in table.Rows)
                        {
                            var fornecedor = new Fornecedor
                            {
                                RazaoSocial = row["Cliente/Fornecedor"].ToString(),
                                NomeFantasia = row["Fantasia"].ToString(),
                                CPF = row["CPF"].ToString(),
                                IE = row["RG/IE"].ToString(),
                                Endereco = row["Endereço"].ToString(),
                                Complemento = row["Complemento"].ToString(),
                                Bairro = row["Bairro"].ToString(),
                                CEP = row["CEP"].ToString(),
                                Numero = row["Número"].ToString(),
                                UF = row["UF"].ToString(),
                                Telefone = row["Telefone/Celular"].ToString(),
                                Email = row["E-mail"].ToString()
                            };
                            response.Add(fornecedor);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Erro ao ler o arquivo Excel: {ex.Message}", ex);
            }

            return response;
        }

        private async void importarXlsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Filter = "Excel Files|*.xls;*.xlsx",
                Title = "Selecione um arquivo Excel"
            };
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string filePath = openFileDialog.FileName;
                try
                {
                    var messageBox = new Form { Text = "Progresso de Importação", Size = new Size(300, 100), StartPosition = FormStartPosition.CenterScreen };
                    var label = new Label { Text = "Iniciando a leitura do arquivo Excel...", Dock = DockStyle.Top };
                    var progressBar = new ProgressBar { Style = ProgressBarStyle.Continuous, Dock = DockStyle.Bottom };
                    messageBox.Controls.Add(progressBar);
                    messageBox.Controls.Add(label);
                    messageBox.Show();

                    List<Fornecedor> fornecedores = ReadXls(filePath);
                    progressBar.Maximum = fornecedores.Count;

                    if (fornecedores.Count > 0)
                    {
                        using (var context = new SgContext())
                        {
                            foreach (var fornecedor in fornecedores)
                            {
                                var existingFornecedor = await context.fornecedor
                                    .AsNoTracking()
                                    .FirstOrDefaultAsync(f => f.CPF == fornecedor.CPF);

                                if (existingFornecedor == null)
                                {
                                    fornecedor.Ativo = "S"; 
                                    fornecedor.Controle = context.fornecedor.Max(f => (int?)f.Controle) + 1 ?? 1; 
                                    context.fornecedor.Add(fornecedor);
                                }
                                else
                                {
                                    fornecedor.Controle = existingFornecedor.Controle; 
                                    context.Entry(existingFornecedor).CurrentValues.SetValues(fornecedor);
                                }
                            }
                            await context.SaveChangesAsync();
                        }
                        MessageBox.Show("Fornecedores importados e salvos no banco de dados com sucesso.", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        using (var context = new SgContext())
                        {
                            dataGridView1.DataSource = context.fornecedor.ToList();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Nenhum fornecedor encontrado no arquivo.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
                catch (DbUpdateException ex)
                {
                    var innerException = ex.InnerException;
                    while (innerException?.InnerException != null)
                    {
                        innerException = innerException.InnerException;
                    }
                    MessageBox.Show($"Erro ao importar o arquivo: {innerException?.Message ?? ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Erro ao importar o arquivo: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void sairToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private async void pictureBox1_Click(object sender, EventArgs e)
        {
            if (BuscaBox.Checked)
            {
                try
                {
                    using (var SGcontext = new DataContext.SgContext())
                    {
                        var fornecedores = await SGcontext.fornecedor.ToListAsync();

                        DataTable dataTable = new DataTable();

                        dataTable.Columns.Add("Codigo", typeof(string));
                        dataTable.Columns.Add("NomeFantasia", typeof(string));
                        dataTable.Columns.Add("RazaoSocial", typeof(string));
                        dataTable.Columns.Add("CPF", typeof(string));
                        dataTable.Columns.Add("RG", typeof(string));
                        dataTable.Columns.Add("CNPJ", typeof(string));
                        dataTable.Columns.Add("Celular", typeof(string));
                        dataTable.Columns.Add("Telefone", typeof(string));
                        dataTable.Columns.Add("Pais", typeof(string));
                        dataTable.Columns.Add("UF", typeof(string));
                        dataTable.Columns.Add("CodCidade", typeof(string));
                        dataTable.Columns.Add("Cidade", typeof(string));
                        dataTable.Columns.Add("Bairro", typeof(string));
                        dataTable.Columns.Add("Endereco", typeof(string));
                        dataTable.Columns.Add("CEP", typeof(string));
                        dataTable.Columns.Add("Numero", typeof(string));
                        dataTable.Columns.Add("Complemento", typeof(string));
                        dataTable.Columns.Add("IE", typeof(string));
                        dataTable.Columns.Add("IM", typeof(string));
                        dataTable.Columns.Add("SAC", typeof(string));
                        dataTable.Columns.Add("Email", typeof(string));
                        dataTable.Columns.Add("Site", typeof(string));
                        dataTable.Columns.Add("FormaPagamento", typeof(string));
                        dataTable.Columns.Add("NomeContatoJuridica", typeof(string));
                        dataTable.Columns.Add("DataHoraCadastro", typeof(DateTime));
                        dataTable.Columns.Add("Campo1", typeof(string));
                        dataTable.Columns.Add("Campo2", typeof(string));
                        dataTable.Columns.Add("Campo3", typeof(string));
                        dataTable.Columns.Add("Campo4", typeof(string));
                        dataTable.Columns.Add("Campo5", typeof(string));
                        dataTable.Columns.Add("Campo6", typeof(string));
                        dataTable.Columns.Add("Campo7", typeof(string));
                        dataTable.Columns.Add("Campo8", typeof(string));
                        dataTable.Columns.Add("Campo9", typeof(string));
                        dataTable.Columns.Add("Campo10", typeof(string));
                        dataTable.Columns.Add("CodCidadeIBGE", typeof(string));
                        dataTable.Columns.Add("Ativo", typeof(string));

                        foreach (var fornecedor in fornecedores)
                        {
                            dataTable.Rows.Add(
                                fornecedor.Controle,
                                fornecedor.NomeFantasia,
                                fornecedor.RazaoSocial,
                                fornecedor.CPF,
                                fornecedor.RG,
                                fornecedor.CNPJ,
                                fornecedor.Celular,
                                fornecedor.Telefone,
                                fornecedor.Pais,
                                fornecedor.UF,
                                fornecedor.CodCidade,
                                fornecedor.Cidade,
                                fornecedor.Bairro,
                                fornecedor.Endereco,
                                fornecedor.CEP,
                                fornecedor.Numero,
                                fornecedor.Complemento,
                                fornecedor.IE,
                                fornecedor.IM,
                                fornecedor.SAC,
                                fornecedor.Email,
                                fornecedor.Site,
                                fornecedor.FormaPagamento,
                                fornecedor.NomeContatoJuridica,
                                fornecedor.DataHoraCadastro,
                                fornecedor.Campo1,
                                fornecedor.Campo2,
                                fornecedor.Campo3,
                                fornecedor.Campo4,
                                fornecedor.Campo5,
                                fornecedor.Campo6,
                                fornecedor.Campo7,
                                fornecedor.Campo8,
                                fornecedor.Campo9,
                                fornecedor.Campo10,
                                fornecedor.CodigoCidadeIBGE,
                                fornecedor.Ativo
                            );
                        }

                        if (dataGridView1.InvokeRequired)
                        {
                            dataGridView1.Invoke(new Action(() => dataGridView1.DataSource = dataTable));
                        }
                        else
                        {
                            dataGridView1.DataSource = dataTable;
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Erro ao buscar dados: {ex.Message}");
                }
            }
            else
            {

            }
        }

        private async void Importar_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Filter = "Excel Files|*.xls;*.xlsx",
                Title = "Selecione um arquivo Excel"
            };
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string filePath = openFileDialog.FileName;
                try
                {
                    var messageBox = new Form { Text = "Progresso de Importação", Size = new Size(300, 100), StartPosition = FormStartPosition.CenterScreen };
                    var label = new Label { Text = "Iniciando a leitura do arquivo Excel...", Dock = DockStyle.Top };
                    var progressBar = new ProgressBar { Style = ProgressBarStyle.Continuous, Dock = DockStyle.Bottom };
                    messageBox.Controls.Add(progressBar);
                    messageBox.Controls.Add(label);
                    messageBox.Show();

                    List<Fornecedor> fornecedores = ReadXls(filePath);
                    progressBar.Maximum = fornecedores.Count;

                    if (fornecedores.Count > 0)
                    {
                        using (var context = new SgContext())
                        {
                            foreach (var fornecedor in fornecedores)
                            {
                                var existingFornecedor = await context.fornecedor
                                    .AsNoTracking()
                                    .FirstOrDefaultAsync(f => f.CPF == fornecedor.CPF);

                                if (existingFornecedor == null)
                                {
                                    fornecedor.Ativo = "S";
                                    fornecedor.Controle = context.fornecedor.Max(f => (int?)f.Controle) + 1 ?? 1;
                                    context.fornecedor.Add(fornecedor);
                                }
                                else
                                {
                                    fornecedor.Controle = existingFornecedor.Controle;
                                    context.Entry(existingFornecedor).CurrentValues.SetValues(fornecedor);
                                }
                            }
                            await context.SaveChangesAsync();
                        }
                        MessageBox.Show("Fornecedores importados e salvos no banco de dados com sucesso.", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        using (var context = new SgContext())
                        {
                            dataGridView1.DataSource = context.fornecedor.ToList();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Nenhum fornecedor encontrado no arquivo.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
                catch (DbUpdateException ex)
                {
                    var innerException = ex.InnerException;
                    while (innerException?.InnerException != null)
                    {
                        innerException = innerException.InnerException;
                    }
                    MessageBox.Show($"Erro ao importar o arquivo: {innerException?.Message ?? ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Erro ao importar o arquivo: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private async void Exportar_Click(object sender, EventArgs e)
        {
            using (SaveFileDialog sfd = new SaveFileDialog() { Filter = "Excel Workbook|*.xlsx" })
            {
                if (sfd.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        var messageBox = new Form { Text = "Progresso de Exportação", Size = new Size(300, 100), StartPosition = FormStartPosition.CenterScreen };
                        var label = new Label { Text = "Iniciando a exportação para Excel...", Dock = DockStyle.Top };
                        var progressBar = new ProgressBar { Style = ProgressBarStyle.Continuous, Dock = DockStyle.Bottom };
                        messageBox.Controls.Add(progressBar);
                        messageBox.Controls.Add(label);
                        messageBox.Show();

                        await Task.Run(() =>
                        {
                            using (var workbook = new XLWorkbook())
                            {
                                var worksheet = workbook.Worksheets.Add("Sheet1");

                                progressBar.Invoke((MethodInvoker)delegate { progressBar.Maximum = dataGridView1.Rows.Count; });

                                for (int i = 0; i < dataGridView1.Columns.Count; i++)
                                {
                                    worksheet.Cell(1, i + 1).Value = dataGridView1.Columns[i].HeaderText;
                                }

                                for (int i = 0; i < dataGridView1.Rows.Count; i++)
                                {
                                    for (int j = 0; j < dataGridView1.Columns.Count; j++)
                                    {
                                        worksheet.Cell(i + 2, j + 1).Value = dataGridView1.Rows[i].Cells[j].Value?.ToString();
                                    }

                                    progressBar.Invoke((MethodInvoker)delegate { progressBar.Value = i + 1; });
                                    label.Invoke((MethodInvoker)delegate { label.Text = $"Exportando linha {i + 1} de {dataGridView1.Rows.Count}..."; });
                                }

                                workbook.SaveAs(sfd.FileName);
                            }
                        });

                        messageBox.Close();

                        MessageBox.Show("Exportação para Excel concluída com sucesso!", "Informação", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Erro ao exportar para Excel: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }
        private void Fornecedores_MouseDown(object sender, MouseEventArgs e)
        {

        }
    }


       
    }

        
    




